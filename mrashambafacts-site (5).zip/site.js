var b=document.getElementById('burger'),m=document.getElementById('menu'),t=document.getElementById('top');
b.addEventListener('click',function(){var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
document.getElementById('yr').textContent=new Date().getFullYear();
t.addEventListener('click',function(){window.scrollTo({top:0})});
window.addEventListener('scroll',function(){t.classList.toggle('show',window.scrollY>600)});
var dlg=document.getElementById('lb');
document.querySelectorAll('.gallery figure').forEach(function(f){f.addEventListener('click',function(){dlg.querySelector('img').src=f.querySelector('img').src;dlg.querySelector('img').alt=f.querySelector('img').alt;dlg.showModal()})});
if(dlg){dlg.addEventListener('click',function(){dlg.close()})}
var fb=document.getElementById('fb');
if(fb){fb.addEventListener('submit',function(e){e.preventDefault();
 var msg='Hello Mra Shamba Facts. I am '+fb.name.value+'. Topic: '+fb.topic.value+'. '+fb.msg.value;
 window.open('https://wa.me/254746677493?text='+encodeURIComponent(msg),'_blank');
 document.getElementById('fbn').textContent='WhatsApp opened with your message. Press send there to finish.'})}
